<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class w_phone extends Model
{
    protected $table = "w_phonenumber";
}
