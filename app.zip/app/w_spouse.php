<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class w_spouse extends Model
{
    protected $table = "w_spouse";
}
