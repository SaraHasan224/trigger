<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class w_socialmedia extends Model
{
    protected $table = "w_socialmedia";
}
