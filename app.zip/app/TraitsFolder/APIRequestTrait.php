<?php
namespace App\TraitsFolder;
use App\PersonalResult;
use App\SourceOptionDetail;
use App\Workbench_Result;
use App\WorkbenchResultDetail;
use Illuminate\Support\Facades\Input;
use Carbon\Carbon;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Auth;
use App\Notification;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Validator;

trait APIRequestTrait
{
    // My custom recursive function for matching score
    public function calc_score($response)
    {
        global $keyCount;
        global $nullCount;
//        dd($response);
//        $json = json_decode($response,true);
        $json = json_decode(json_encode($response),true);
        $keyCount = $nullCount = 0;
        array_walk_recursive($json, 'self::recursive');

        $percentage = ($keyCount-$nullCount)/$keyCount;
        $percent = number_format($percentage,1);
//        echo "<p>Key: $keyCount, Null: $nullCount, Percentage: $percent";
        return $percent;
    }

    //Call our recursive function for removing null values from responses received.
    public function recursive($item, $key)
    {
        global $keyCount, $nullCount;
        $keyCount++;
        if(empty($item)) {
            $nullCount++;
        }
//        echo "$key holds <b>$item</b>\n";
//        echo "<br/>";
    }








    /*
    *   API CURL Request Call functions below
    */

    public function rocket_reach($names,$company_name,$job_title)
    {
        $rocket_key = env('ROCKET_REACH_API_KEY', '3E7k0123456789abcdef0123456789abcdef');
        $rocket_client = new Client();
        $rocket_url = 'https://api.rocketreach.co/v1/api/lookupProfile?'.
            'api_key=' . $rocket_key .
            '&name='.urlencode($names);
        if($company_name != "") $rocket_url .= '&current_employer='.urlencode($company_name);
        if($job_title != "") $rocket_url .= '&title='.urlencode($job_title);
        if("" != "") $rocket_url .= '&twitter_handle=';
        if("" != "") $rocket_url .= '&twitter_url=';
        if("" != "") $rocket_url .= '&li_url=';
        $rocket_request = $rocket_client->get($rocket_url);
        $rocket_response = json_decode($rocket_request->getBody()->getContents());

        return ($rocket_response);

        //LookUp
        //li_url    	LinkedIn URL e.g. 'https://www.linkedin.com/in/marcbenioff
        //twitter_handle    	Twitter Handle (e.g. use 'joandoe' instead of '@joandoe')
        //twitter_url    	Twitter Handle (e.g. 'https://twitter.com/joandoe')
        //Search
        //name	Name of the person you are looking for
        //keyword	Keyword: Any keywords in a person's profile
        //title	Title: (e.g. 'VP of Marketing', 'CEO')
        //company	Company: (e.g. 'Google', 'General Electric')
        //location	Location: (e.g. 'San Francisco', 'San Francisco Bay Area')
    }

    public function block_dispossal($p_email)
    {
        $block_response = [];
        for($i=0;$i<count($p_email);$i++){
            // Block Dispossal Emails
            $block_key = env('BLOCK_DISPOSSAL_EMAIL_API_KEY', '34878a526de1cb0e5f0de6a6481204d7');
            $block_client = new Client();
            $block_request = $block_client->get('http://check.block-disposable-email.com/easyapi/json/'.$block_key.'/'.$p_email[$i]);
            $response = $block_request->getBody()->getContents();
            $bd_response[$i] = json_decode($response);
        }
        return ($bd_response);
    }

    public function hibp($p_email)
    {
        // Block Dispossal Emails
        $HIBP_key = env('HAVE_I_BEEN_PWNED_API_KEY', '34878a526de1cb0e5f0de6a6481204d7');
        $HIBP_client = new Client(['headers' => ['hibp-api-key' => $HIBP_key]]);
        // PARAMETER = Adobe
        $HIBP_request = $HIBP_client->get('https://haveibeenpwned.com/api/v3/breachedaccount/ADOBE');
        $response = $HIBP_request->getBody()->getContents();
        $hibp_response = json_decode($response);
        return ($hibp_response);
    }

    public function byteplant_phone_validate($phone_number,$country_code,$country_lang_code)
    {
        //$phone,$code,$locale
        // build API request
        $APIUrl = 'https://api.phone-validator.net/api/v2/verify';
        $CountryCode = $country_code[0];
        $PhoneNumber = $phone_number[0];
        $Params = [
            'PhoneNumber' => $PhoneNumber,
            'CountryCode' => $CountryCode,
            'Locale' => $country_lang_code,
            'APIKey' => env('PHONE_VALIDATOR_API_KEY', 'pv-906e682fb2b260c5ec772b71db168f52')
        ];
        $Request = http_build_query($Params, '', '&');
        $ctxData = array(
            'method'=>"POST",
            'header'=>"Connection: close\r\n".
                "Content-Type: application/x-www-form-urlencoded\r\n".
                "Content-Length: ".strlen($Request)."\r\n",
            'content'=>$Request);
        $ctx = stream_context_create(array('http' => $ctxData));

        // send API request
        $result = json_decode(file_get_contents($APIUrl, false, $ctx));
//        dd($result->{'status'});
        // check API result
        switch($result->{'status'}) {
            case "VALID_CONFIRMED":
                $response = 'valid';
                break;
            case "VALID_UNCONFIRMED":
                $linetype = $result->{'linetype'};
                $location = $result->{'location'};
                $countrycode = $result->{'countrycode'};
                $formatnational = $result->{'formatnational'};
                $formatinternational = $result->{'formatinternational'};
                $response =  'valid';
                break;
            case "INVALID":
                $response = 'invalid';
                break;
            default:
                $response = 'invalid';
        }
        return($response);
    }

    public function byteplant_address_validate($StreetAddress,$City,$PostalCode,$State,$CountryCode,$Locale)
    {
        // build API request
        $APIUrl = 'https://api.address-validator.net/api/verify';
        $Params = [
            'StreetAddress' => $StreetAddress,
            'City' => $City,
            'PostalCode' => $PostalCode,
            'State' => $State,
            'CountryCode' => $CountryCode,
            'Locale' => $Locale,
            'APIKey' => env('ADDRESS_VALIDATOR_API_KEY', 'av-cf6de170ac7cb129b474fd262bd2d37a')
        ];
        $Request = http_build_query($Params, '', '&');
        $ctxData = array(
            'method'=>"POST",
            'header'=>"Connection: close\r\n".
                "Content-Type: application/x-www-form-urlencoded\r\n".
                "Content-Length: ".strlen($Request)."\r\n",
            'content'=>$Request);
        $ctx = stream_context_create(array('http' => $ctxData));

        // send API request
        $result = json_decode(file_get_contents(
            $APIUrl, false, $ctx));

        // check API result
        if ($result && $result->{'status'} == 'VALID') {
            $formattedaddress = $result->{'formattedaddress'};
        } else {
            $formattedaddress = $result;
        }
    }

    public function everyoneAPI($country_code,$number)
    {
        $block_response = [];
        for($i=0;$i<count($number);$i++){
            // Block Dispossal Emails
            $phone_number = '+'.$country_code.$number[0];
            $account_SID = env('EVERYONE_API_ACCOUNT_SID', 'AC38c6e769a11d428d9ba0370c98eb8c71');
            $auth_token = env('EVERYONE_API_AUTH_TOKEN', 'AU6428612b587b4c95a0cbebbd12cbe0db');
            $client = new Client();
            $request = $client->get('https://api.everyoneapi.com/v1/phone/'.$phone_number.'?account_sid='.$account_SID.'&auth_token='.$auth_token.'&data=name,address,location,cnam,carrier,carrier_o,gender,linetype,image,line_provider,profile');
            $response = $request->getBody()->getContents();
            $block_response[$i] = json_decode($response);
        }
        dd($block_response);
        return ($block_response);
    }

    /*
     *

        *   Clearbit API  CURL & Response Handling Starts Here
    */

    /*
    public function clearbit($workbench_id)
    {
        global $final_res;
        $response = '{
                          "person": {
                            "id": "d75f156b-c95e-4b81-9e77-d4492d7515e1",
                            "name": {
                              "fullName": "John Pagliaro",
                              "givenName": "John",
                              "familyName": "Pagliaro"
                            },
                            "email": "jpagliaro@structureinsgroup.com",
                            "location": "Hartford, CT, US",
                            "timeZone": "America/New_York",
                            "utcOffset": -4,
                            "geo": {
                              "city": "Hartford",
                              "state": "Connecticut",
                              "stateCode": "CT",
                              "country": "United States",
                              "countryCode": "US",
                              "lat": 41.7658043,
                              "lng": -72.6733723
                            },
                            "bio": null,
                            "site": null,
                            "avatar": null,
                            "employment": {
                              "domain": "structureinsgroup.com",
                              "name": "Structure Insurance Group",
                              "title": "President",
                              "role": "leadership",
                              "subRole": "president",
                              "seniority": "executive"
                            },
                            "facebook": {
                              "handle": null
                            },
                            "github": {
                              "handle": null,
                              "id": null,
                              "avatar": null,
                              "company": null,
                              "blog": null,
                              "followers": null,
                              "following": null
                            },
                            "twitter": {
                              "handle": null,
                              "id": null,
                              "bio": null,
                              "followers": null,
                              "following": null,
                              "statuses": null,
                              "favorites": null,
                              "location": null,
                              "site": null,
                              "avatar": null
                            },
                            "linkedin": {
                              "handle": "in/john-pagliaro-jr-mba-cris-8a0a8b13"
                            },
                            "googleplus": {
                              "handle": null
                            },
                            "gravatar": {
                              "handle": null,
                              "urls": [],
                              "avatar": null,
                              "avatars": []
                            },
                            "fuzzy": false,
                            "emailProvider": false,
                            "indexedAt": "2019-10-15T06:15:47.172Z"
                          },
                          "company": {
                            "id": "53b718a1-a074-4e3f-88fc-85e1fcd093d2",
                            "name": "Structure Insurance Group",
                            "legalName": null,
                            "domain": "structureinsgroup.com",
                            "domainAliases": [],
                            "site": {
                              "phoneNumbers": [
                                "+1 860-987-2151"
                              ],
                              "emailAddresses": [
                                "jpagliaro@structureinsgroup.com",
                                "pagliaro@structureinsgroup.com"
                              ]
                            },
                            "category": {
                              "sector": null,
                              "industryGroup": null,
                              "industry": null,
                              "subIndustry": null,
                              "sicCode": "64",
                              "naicsCode": "52"
                            },
                            "tags": [
                              "B2B"
                            ],
                            "description": "John Pagliaro serves Western MA and the surrounding areas of MA and CT and is dedicated to providing quality customer service to each and every client.    General Information    Structure Insurance Group licensed in MA & CT  Representing American Natio...",
                            "foundedYear": null,
                            "location": "504 College Hwy, Southwick, MA 01077, USA",
                            "timeZone": "America/New_York",
                            "utcOffset": -4,
                            "geo": {
                              "streetNumber": "504",
                              "streetName": "College Highway",
                              "subPremise": null,
                              "city": "Southwick",
                              "postalCode": "01077",
                              "state": "Massachusetts",
                              "stateCode": "MA",
                              "country": "United States",
                              "countryCode": "US",
                              "lat": 42.056025,
                              "lng": -72.76813489999999
                            },
                            "logo": null,
                            "facebook": {
                              "handle": "structureinsurancegroupllc",
                              "likes": 234
                            },
                            "linkedin": {
                              "handle": null
                            },
                            "twitter": {
                              "handle": null,
                              "id": null,
                              "bio": null,
                              "followers": null,
                              "following": null,
                              "location": null,
                              "site": null,
                              "avatar": null
                            },
                            "crunchbase": {
                              "handle": null
                            },
                            "emailProvider": false,
                            "type": "private",
                            "ticker": null,
                            "identifiers": {
                              "usEIN": null
                            },
                            "phone": null,
                            "metrics": {
                              "alexaUsRank": null,
                              "alexaGlobalRank": 7845689,
                              "employees": null,
                              "employeesRange": null,
                              "marketCap": null,
                              "raised": null,
                              "annualRevenue": null,
                              "estimatedAnnualRevenue": null,
                              "fiscalYearEnd": null
                            },
                            "indexedAt": "2019-10-02T05:09:24.571Z",
                            "tech": [
                              "microsoft_exchange_online",
                              "google_cloud",
                              "facebook_connect",
                              "go_squared"
                            ],
                            "parent": {
                              "domain": null
                            },
                            "ultimate_parent": {
                              "domain": null
                            }
                          }
                        }';
        $score = $this->calc_score(json_decode($response, true));
        $final_res = $this->getResults($workbench_id,$score,$response);
    }
    */
    public function copy_clearbit($workbench_id)
    {
        global $final_res;
        /*
             The supported parameters are:
                email, webhook_url, given_name(First name of person), family_name, ip_address, location, company, company_domain
                linkedin, twitter, facebook
        */

        $first_name = escape(Input::get('first_name'));
        $middle_name = escape(Input::get('middle_name'));
        $last_name = escape(Input::get('last_name'));
        if ($middle_name != '') {
            $names = $first_name . ' ' . $middle_name . ' ' . $last_name;
        }
        else {
            $names = $first_name . ' ' . $last_name;
        }


        $email = Input::get('p_email');
        $company = Input::get('emp_cmp_name');
        $f_name = Input::get('first_name');
        $l_name = Input::get('last_name');
        $location = Input::get('p_city');
        $company = Input::get('employer_name');
        //$linkedin = Input::get('p_email');        The LinkedIn URL for the person.
        //$twitter = Input::get('p_email');         The Twitter handle for the person.
        //$facebook = Input::get('p_email');        The Facebook URL for the person.

        $secret_key= env('CLEARBIT_SECRET_API_KEY');
        $endpoint= 'https://person-stream.clearbit.com/v2/combined/find?';
        if(!empty($email))
        {
            $endpoint.= 'email='.$email;
        }
        if(!empty($company))
        {
            $endpoint.= '&company='.$company;
        }
        if(!empty($f_name))
        {
            $endpoint.= '&given_name='.$f_name;
        }
        if(!empty($l_name))
        {
            $endpoint.= '&family_name='.$l_name;
        }
        if(!empty($location))
        {
            $endpoint.= '&location='.$location;
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Accept: */*",
//                    "Accept-Encoding: gzip, deflate",
                "Authorization: Basic c2tfNWIyODdiZmZmNWU0ZmUzYWMxOGJlZGUwNmU1NmYxZTU6",
                "Cache-Control: no-cache",
                "Connection: keep-alive",
                "Host: person-stream.clearbit.com",
//                    "Postman-Token: 703c392e-fbc8-40a5-b331-aad5707b4d6f,0448b996-1469-4480-a47f-6a9701fef06c",
//                    "User-Agent: PostmanRuntime/7.18.0",
                "cache-control: no-cache"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        if ($err) {
            echo "cURL Error #:" . $err;
            die;
        }
        else {
            // Get match score
            if($response != null || $response != "")
            {
                $score = $this->calc_score(json_decode($response,true));
                dump($score);
                $final_res = $this->getResults(json_decode($response,true));
                dump($final_res);
                die();
                Notification::Notify(
                    (Auth::user()->user_type == 1)  ? 1 : Auth::user()->user_type,
                    $this->to_id,
                    "User: ".Auth::user()->name." (Having Role: ".Auth::user()->role->name.") "."searched person record against name: ".$names." successfully using Clearbit API",
                    '/admin-dashboard/workbench/personal/result/'.$workbench_id,
                    Auth::user()->id,
                    ' bg-inverse-secondary text-info',
                    'mdi mdi-account-search'
                );

                // Save record in a Database
                $result = new Workbench_Result();
                $result->workbench_id = $workbench_id;
                $result->response = $response;
                $result->result = json_encode($final_res);
                $result->source_options_id = 14;
                $result->score = $score;
                $result->save();
            }
            else{
                print_r('Error while proceeding request');
                return redirect()->back()->with('warning_msg', "Error while proceeding request.");
            }
        }
    }
    public function clearbit($workbench_id)
    {
        global $final_res;
        /*
             The supported parameters are:
                email, webhook_url, given_name(First name of person), family_name, ip_address, location, company, company_domain
                linkedin, twitter, facebook
        */

        $first_name = escape(Input::get('first_name'));
        $middle_name = escape(Input::get('middle_name'));
        $last_name = escape(Input::get('last_name'));
        if ($middle_name != '') {
            $names = $first_name . ' ' . $middle_name . ' ' . $last_name;
        }
        else {
            $names = $first_name . ' ' . $last_name;
        }


        $email = Input::get('p_email');
        $company = Input::get('emp_cmp_name');
        $f_name = Input::get('first_name');
        $l_name = Input::get('last_name');
        $location = Input::get('p_city');
        $company = Input::get('employer_name');
        //$linkedin = Input::get('p_email');        The LinkedIn URL for the person.
        //$twitter = Input::get('p_email');         The Twitter handle for the person.
        //$facebook = Input::get('p_email');        The Facebook URL for the person.

        $secret_key= env('CLEARBIT_SECRET_API_KEY');
        $endpoint= 'https://person-stream.clearbit.com/v2/combined/find?';
        if(!empty($email))
        {
            $endpoint.= 'email='.$email;
        }
        if(!empty($company))
        {
            $endpoint.= '&company='.$company;
        }
        if(!empty($f_name))
        {
            $endpoint.= '&given_name='.$f_name;
        }
        if(!empty($l_name))
        {
            $endpoint.= '&family_name='.$l_name;
        }
        if(!empty($location))
        {
            $endpoint.= '&location='.$location;
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Accept: */*",
//                    "Accept-Encoding: gzip, deflate",
                "Authorization: Basic c2tfNWIyODdiZmZmNWU0ZmUzYWMxOGJlZGUwNmU1NmYxZTU6",
                "Cache-Control: no-cache",
                "Connection: keep-alive",
                "Host: person-stream.clearbit.com",
//                    "Postman-Token: 703c392e-fbc8-40a5-b331-aad5707b4d6f,0448b996-1469-4480-a47f-6a9701fef06c",
//                    "User-Agent: PostmanRuntime/7.18.0",
                "cache-control: no-cache"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        if ($err) {
            echo "cURL Error #:" . $err;
            die;
        }
        else {
            // Get match score
            if($response != null || $response != "")
            {
                $score = $this->calc_score(json_decode($response, true));
                $final_res = $this->getResults($workbench_id,$score,$response);
//                Notification::Notify(
//                    (Auth::user()->user_type == 1)  ? 1 : Auth::user()->user_type,
//                    $this->to_id,
//                    "User: ".Auth::user()->name." (Having Role: ".Auth::user()->role->name.") "."searched person record against name: ".$names." successfully using Clearbit API",
//                    '/admin-dashboard/workbench/personal/result/'.$workbench_id,
//                    Auth::user()->id,
//                    ' bg-inverse-secondary text-info',
//                    'mdi mdi-account-search'
//                );
            }
            else{
                print_r('Error while proceeding request');
                return redirect()->back()->with('warning_msg', "Error while proceeding request.");
            }
        }
    }
    //  Calculate Clearbit API result
    function parse_clearbit_json($item, $key,$arr_values)
    {
        global $result_api;
        global $final_res;
        global $i;
        $i++;
        $current_res = $arr_values['res_key'];
        $identifier = $arr_values['key'];
        $sub_array = ['phone', 'github', 'twitter', 'facebook', 'linkedin', 'gravatar', "crunchbase"];

//    echo '<br/>Iteration Number: ' . $i . ' has object <b>' . $current_res . '</b> with keyname: <b>' . $identifier . '</b> with key <b>' . $key . '</b> has <b>' . $item . '</b>';

        if (!is_array($result_api[$current_res])) {
            return false;
        }
        else {
            foreach ($result_api[$current_res] as $r_key => $r_val) {
                if ($r_key == $key) {
                    if (!is_array($r_val)) {
                        $final_res["$current_res"][$identifier][$r_key] = $r_val;
                    }
                    else if (in_array($key, $sub_array)) {
                        $final_res[$current_res][$identifier][$r_key][$item] = $r_val[$item];
                    }
                    else {
                        if ($item == "") {
                            $final_res["$current_res"][$identifier][$item] = "";
                        }
                        elseif ($item == []) {
                            $final_res["$current_res"][$identifier][$item] = [];
                        }
                        else {
                            if (array_key_exists($item, $r_val) == 1) {
                                $final_res["$current_res"][$identifier][$item] = $r_val[$item];
                            }
                            else {

                                $final_res["$current_res"][$identifier][$item] = "";
                            }
                        }
                    }


                }
            }
        }
    }

    public function getResults($workbench_id,$score,$result)
    {
        global $result_api;
        global $final_res;
//         dd($result);
//        foreach ($result as $item) {

            $result_api = json_decode($result,true);
//            $result_api = $result;
            $final_res = [];
            foreach ($result_api as $res_key => $v)
            {
                if($res_key == "person")
                {
                    $json  = '{"personal":{"name":{"person":{"name":"fullName"}},"bio":{"person":{"bio":"bio"}},"site":{"person":{"site":"site"}},"avatar":{"person":{"avatar":"avatar"}}},"email":{"email":{"person":{"email":"email"}}},"geo_location":{"latitude":{"person":{"geo":"lat"}},"longitude":{"person":{"geo":"lng"}},"state":{"person":{"geo":"state"}},"stateCode":{"person":{"geo":"stateCode"}},"city":{"person":{"geo":"city"}},"country":{"person":{"geo":"country"}},"countryCode":{"person":{"geo":"countryCode"}},"timezone":{"person":{"timeZone":"timeZone"}}},"location":{"location":{"person":{"location":"location"}}},"employment":{"name":{"person":{"employment":"name"}},"role":{"person":{"employment":"role"}},"title":{"person":{"employment":"title"}},"domain":{"person":{"employment":"domain"}},"subRole":{"person":{"employment":"subRole"}},"seniority":{"person":{"employment":"seniority"}}},"social_profile":{"github":{"id":{"person":{"github":"id"}},"blog":{"person":{"github":"blog"}},"avatar":{"person":{"github":"avatar"}},"handle":{"person":{"github":"handle"}},"company":{"person":{"github":"company"}},"followers":{"person":{"github":"followers"}},"following":{"person":{"github":"following"}}},"twitter":{"id":{"person":{"twitter":"id"}},"bio":{"person":{"twitter":"bio"}},"site":{"person":{"twitter":"site"}},"avatar":{"person":{"twitter":"avatar"}},"handle":{"person":{"twitter":"handle"}},"statuses":{"person":{"twitter":"statuses"}},"favorites":{"person":{"twitter":"favorites"}},"followers":{"person":{"twitter":"followers"}},"following":{"person":{"twitter":"following"}}},"facebook":{"handle":{"person":{"facebook":"handle"}}},"gravatar":{"urls":{"person":{"gravatar":"urls"}},"avatar":{"person":{"gravatar":"avatar"}},"handle":{"person":{"gravatar":"handle"}},"avatars":{"person":{"gravatar":"avatars"}}},"linkedin":{"person":{"linkedin":"handle"}}}}';
                }
                elseif ($res_key == "company")
                {
                    $json  = '{"geo_location":{"latitude":{"company":{"geo":"lat"}},"longitude":{"company":{"geo":"lng"}},"suitNumber":{"company":{"geo":"subPremise"}},"streetNumber":{"company":{"geo":"streetNumber"}},"streetName":{"company":{"geo":"streetName"}},"state":{"company":{"geo":"state"}},"stateCode":{"company":{"geo":"stateCode"}},"city":{"company":{"geo":"city"}},"country":{"company":{"geo":"country"}},"countryCode":{"company":{"geo":"countryCode"}},"timeZone":{"company":{"timeZone":"timeZone"}}},"email":{"company":{"site":"emailAddresses"}},"phone":{"phone_number":{"company":{"site":"phoneNumbers"}},"phone":{"company":{"phone":"phone"}}},"location":{"company":{"location":"location"}},"business":{"name":{"company":{"name":"name"}},"logo":{"company":{"logo":"logo"}},"tags":{"company":{"tags":"tags"}},"type":{"company":{"type":"type"}},"domain":{"company":{"domain":"domain"}},"legalName":{"company":{"legalName":"legalName"}},"foundedYear":{"company":{"foundedYear":"foundedYear"}},"description":{"company":{"description":"description"}},"parent_domain":{"company":{"parent":"domain"}}},"stock_reports":{"company":{"ticker":"ticker"}},"technology":{"company":{"tech":"tech"}},"metrics":{"raised":{"company":{"metrics":"raised"}},"annualRevenue":{"company":{"metrics":"annualRevenue"}},"market_cap":{"company":{"metrics":"marketCap"}},"alexa_rank":{"company":{"metrics":"alexaUsRank"}},"alexa_global_rank":{"company":{"metrics":"alexaGlobalRank"}},"fiscalYearEnd":{"company":{"metrics":"fiscalYearEnd"}},"employee_range":{"company":{"metrics":"employeesRange"}},"estimatedAnnualRevenue":{"company":{"metrics":"estimatedAnnualRevenue"}}},"category":{"sector":{"company":{"category":"sector"}},"sicCode":{"company":{"category":"sicCode"}},"industry":{"company":{"category":"industry"}},"naicsCode":{"company":{"category":"naicsCode"}},"subIndustry":{"company":{"category":"subIndustry"}},"industryGroup":{"company":{"category":"industryGroup"}}},"social":{"twitter":{"id":{"company":{"twitter":"id"}},"bio":{"company":{"twitter":"bio"}},"site":{"company":{"twitter":"site"}},"avatar":{"company":{"twitter":"avatar"}},"handle":{"company":{"twitter":"handle"}},"location":{"company":{"twitter":"location"}},"followers":{"company":{"twitter":"followers"}},"following":{"company":{"twitter":"following"}}},"facebook":{"likes":{"company":{"facebook":"likes"}},"handle":{"company":{"facebook":"handle"}}},"linkedin":{"handle":{"company":{"linkedin":"handle"}}},"crunchbase_handle":{"company":{"crunchbase":"handle"}}}}';
                }
                $result_json = json_decode($json,true);
                foreach ($result_json as $key => $v)
                {
                    $send = [
                        "key" => $key,
                        "res_key" => $res_key
                    ];
//                        dd($result_json[$key],$send);
                    array_walk_recursive($result_json[$key], 'self::parse_clearbit_json',$send);
                }
            }
//            return $final_res;
//        dump($result);
//        dump($final_res);
//        dd(json_encode($final_res));
        // Save record in a Database

        $result = Workbench_Result::create([
            'workbench_id' => $workbench_id,
            'response' => $result,
            'result' => json_encode($final_res),
            'source_options_id' => 14,
            'score' => $score,
            'workbench_id' => $workbench_id,
            "type" => 0,
        ]);

//        $final_res
        function array_unique_recursive($array)
        {
            $array = array_unique($array, SORT_REGULAR);
            foreach ($array as $key => $elem) {
                if (is_array($elem)) {
                    $array[$key] = array_unique_recursive($elem);
                }
            }
            return $array;
        }
//        Final Result Manipulation
        $res_det = [];
        //  Name
        $res_det['name'] = [];
        if (array_key_exists('person', $final_res))
        {
            array_push($res_det['name'], $final_res['person']['personal']['fullName']);
        }
        $res_det['name'] = array_unique($res_det['name']);
        //  Email
        $res_det['email'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['email']['email'] != null) {
                array_push($res_det['email'], $final_res['person']['email']['email']);
            }
        }
        if(array_key_exists('company', $final_res))
        {
            foreach($final_res['company']['email']['emailAddresses'] as $em)
            {
                if($em != null)
                {
                    array_push($res_det['email'], $em);
                }
            }
        }
        $res_det['email'] = array_unique($res_det['email']);
        //Avatar
        $res_det['avatar'] = [];
        if (array_key_exists('person', $final_res))
        {
            array_push($res_det['avatar'], $final_res['person']['personal']['avatar']);
        }
        //Bio
        $res_det['bio'] = [];
        if (array_key_exists('person', $final_res))
        {
            array_push($res_det['bio'], $final_res['person']['personal']['bio']);
        }
        //site
        $res_det['site'] = [];
        if (array_key_exists('person', $final_res))
        {
            array_push($res_det['site'], $final_res['person']['personal']['site']);
        }
        //location
        $res_det['location'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['location']['location'] != null) {
                array_push($res_det['location'], $final_res['person']['location']['location']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if($final_res['company']['location']['location'] != null)
            {
                array_push($res_det['location'], $final_res['company']['location']['location']);
            }
        }
        $res_det['location'] = array_unique($res_det['location']);
        //longitude
        $res_det['longitude'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['geo_location']['lng'] != null) {
                array_push($res_det['longitude'], $final_res['person']['geo_location']['lng']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if($final_res['company']['geo_location']['lng'] != null) {
                array_push($res_det['longitude'], $final_res['company']['geo_location']['lng']);
            }
        }
        $res_det['longitude'] = array_unique($res_det['longitude']);
        //latitude
        $res_det['latitude'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['geo_location']['lat'] != null) {
                array_push($res_det['latitude'], $final_res['person']['geo_location']['lat']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if($final_res['company']['geo_location']['lat'] != null) {
                array_push($res_det['latitude'], $final_res['company']['geo_location']['lat']);
            }
        }
        $res_det['latitude'] = array_unique($res_det['latitude']);
        //city
        $res_det['city'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['geo_location']['city'] != null) {
                array_push($res_det['city'], $final_res['person']['geo_location']['city']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if($final_res['company']['geo_location']['city'] != null) {
                array_push($res_det['city'], $final_res['company']['geo_location']['city']);
            }
        }
        $res_det['city'] = array_unique($res_det['city']);
        //state
        $res_det['state'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['geo_location']['state'] != null) {
                array_push($res_det['state'], $final_res['person']['geo_location']['state']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if($final_res['company']['geo_location']['state'] != null) {
                array_push($res_det['state'],$final_res['company']['geo_location']['state']);
            }
        }
        $res_det['state'] = array_unique($res_det['state']);
        //country
        $res_det['country'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['geo_location']['country'] != null) {
                array_push($res_det['country'],$final_res['person']['geo_location']['country']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if($final_res['company']['geo_location']['country'] != null) {
                array_push($res_det['country'],$final_res['company']['geo_location']['country']);
            }
        }
        $res_det['country'] = array_unique($res_det['country']);
        //timezone
        $res_det['timezone'] = [];
        if (array_key_exists('person', $final_res))
        {
            if($final_res['person']['geo_location']['timeZone'] != null) {
                array_push($res_det['timezone'],$final_res['person']['geo_location']['timeZone']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if($final_res['company']['geo_location']['timeZone'] != null) {
                array_push($res_det['timezone'],$final_res['company']['geo_location']['timeZone']);
            }
        }
        $res_det['timezone'] = array_unique($res_det['timezone']);
        //career
        $res_det['career'] = [
            'name' => [],
            'logo' => [],
            'title' => [],
            'domain' => [],
            'role' => [],
            'description' => [],
            'foundedYear' => [],
            'type' => [],
        ];
        if (array_key_exists('person', $final_res))
        {
            if (array_key_exists('employment', $final_res['person'])) {
                array_push($res_det['career']['name'],$final_res['person']['employment']['name']);
                array_push($res_det['career']['title'],$final_res['person']['employment']['title']);
                if($final_res['person']['employment']['domain'] != null) {
                    array_push($res_det['career']['domain'], $final_res['person']['employment']['domain']);
                }
                array_push($res_det['career']['role'],$final_res['person']['employment']['role']);
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if (array_key_exists('business', $final_res['company'])) {
                if($final_res['company']['business']['name'] != null) {
                    array_push($res_det['career']['name'], $final_res['company']['business']['name']);
                }
                array_push($res_det['career']['logo'],$final_res['company']['business']['logo']);
                if($final_res['company']['business']['domain'] != null) {
                    array_push($res_det['career']['domain'], $final_res['company']['business']['domain']);
                }
                array_push($res_det['career']['type'],$final_res['company']['business']['type']);
                array_push($res_det['career']['description'],$final_res['company']['business']['description']);
                array_push($res_det['career']['foundedYear'],$final_res['company']['business']['foundedYear']);
            }
        }
        $res_det['career'] = array_unique_recursive($res_det['career']);

        //social
        $res_det['social'] = [
            'github' => [
                "company" => [],
                "handle" => [],
                "follower" => [],
                "following" => []
            ],
            'twitter' => [
                "bio" => [],
                "handle" => [],
                "site" => [],
                "follower" => [],
                "following" => []
            ],
            'facebook' => [
                "likes" => [],
                "handle" => []
            ],
            'linkedin' => [
                "handle" => []
            ],
            'crunchbase' => [
                "handle" => []
            ]
        ];
        if (array_key_exists('person', $final_res))
        {
            if (array_key_exists('social_profile', $final_res['person'])) {
                //  Github
                if($final_res['person']['social_profile']['github']['company'] != null)
                {
                    array_push($res_det['social']['github']['company'],$final_res['person']['social_profile']['github']['company']);
                }
                if($final_res['person']['social_profile']['github']['handle'] != null) {
                    array_push($res_det['social']['github']['handle'], $final_res['person']['social_profile']['github']['handle']);
                }
                if($final_res['person']['social_profile']['github']['followers'] != null) {
                    array_push($res_det['social']['github']['follower'], $final_res['person']['social_profile']['github']['followers']);
                }
                if($final_res['person']['social_profile']['github']['following'] != null) {
                    array_push($res_det['social']['github']['following'],$final_res['person']['social_profile']['github']['following']);
                }
                //  Twitter
                if($final_res['person']['social_profile']['twitter']['bio'] != null) {
                    array_push($res_det['social']['twitter']['bio'], $final_res['person']['social_profile']['twitter']['bio']);
                }
                if($final_res['person']['social_profile']['twitter']['handle'] != null) {
                    array_push($res_det['social']['twitter']['handle'], $final_res['person']['social_profile']['twitter']['handle']);
                }
                if($final_res['person']['social_profile']['twitter']['site'] != null) {
                    array_push($res_det['social']['twitter']['site'], $final_res['person']['social_profile']['twitter']['site']);
                }
                if($final_res['person']['social_profile']['twitter']['followers'] != null) {
                    array_push($res_det['social']['twitter']['follower'], $final_res['person']['social_profile']['twitter']['followers']);
                }
                if($final_res['person']['social_profile']['twitter']['following'] != null) {
                    array_push($res_det['social']['twitter']['following'], $final_res['person']['social_profile']['twitter']['following']);
                }
                //  Facebook
                if($final_res['person']['social_profile']['facebook']['handle'] != null) {
                    array_push($res_det['social']['facebook']['handle'], $final_res['person']['social_profile']['facebook']['handle']);
                }
                // Linkedin
                if($final_res['person']['social_profile']['facebook']['handle'] != null) {
                    array_push($res_det['social']['linkedin']['handle'], $final_res['person']['social_profile']['linkedin']['handle']);
                }
            }
        }
        if (array_key_exists('company', $final_res))
        {
            if (array_key_exists('social', $final_res['company'])) {
                //  Twitter
                if($final_res['company']['social']['twitter']['bio'] != null) {
                    array_push($res_det['social']['twitter']['bio'], $final_res['company']['social']['twitter']['bio']);
                }
                if($final_res['company']['social']['twitter']['handle'] != null) {
                    array_push($res_det['social']['twitter']['handle'], $final_res['company']['social']['twitter']['handle']);
                }
                if($final_res['company']['social']['twitter']['site'] != null) {
                    array_push($res_det['social']['twitter']['site'], $final_res['company']['social']['twitter']['site']);
                }
                if($final_res['company']['social']['twitter']['followers'] != null) {
                    array_push($res_det['social']['twitter']['follower'], $final_res['company']['social']['twitter']['followers']);
                }
                if($final_res['company']['social']['twitter']['following'] != null) {
                    array_push($res_det['social']['twitter']['following'], $final_res['company']['social']['twitter']['following']);
                }
                //  Facebook
                if($final_res['company']['social']['facebook']['likes'] != null) {
                    array_push($res_det['social']['facebook']['likes'], $final_res['company']['social']['facebook']['likes']);
                }
                if($final_res['company']['social']['facebook']['handle'] != null) {
                    array_push($res_det['social']['facebook']['handle'], $final_res['company']['social']['facebook']['handle']);
                }
                // Linkedin
                if($final_res['company']['social']['linkedin']['handle'] != null) {
                    array_push($res_det['social']['linkedin']['handle'], $final_res['company']['social']['linkedin']['handle']);
                }
                // Crunchbase
                if($final_res['company']['social']['crunchbase']['handle'] != null) {
                    array_push($res_det['social']['crunchbase']['handle'],$final_res['company']['social']['crunchbase']['handle']);
                }

            }
        }
        $res_det['social'] = array_unique_recursive($res_det['social']);

//        dd($res_det);

        $result_save = new PersonalResult();
        $result_save->workbench__results_id = $result->id;
        $result_save->name = json_encode($res_det['name']);
        $result_save->email = json_encode($res_det['email']);
        $result_save->age = NULL;
        $result_save->gender = NULL;
        $result_save->language = NULL;
        $result_save->dob = NULL;
        $result_save->avatar = json_encode($res_det['avatar']);
        $result_save->bio = json_encode($res_det['bio']);
        $result_save->site = json_encode($res_det['site']);
        $result_save->phone_number = NULL;
        $result_save->images = NULL;
        $result_save->urls = NULL;
        $result_save->ethnicity = NULL;
        $result_save->origin_country = NULL;
        $result_save->relations = NULL;
        $result_save->location = json_encode($res_det['location']);
        $result_save->longitude = json_encode($res_det['longitude']);
        $result_save->latitude = json_encode($res_det['latitude']);
        $result_save->state = json_encode($res_det['state']);
        $result_save->city = json_encode($res_det['city']);
        $result_save->country = json_encode($res_det['country']);
        $result_save->zip_code = NULL;
        $result_save->timezone = json_encode($res_det['timezone']);
        $result_save->career = json_encode($res_det['career']);
        $result_save->education = NULL;
        $result_save->social = json_encode($res_det['social']);
        $result_save->save();
    }


    /*
        *   Clearbit API  CURL & Response Handling Ends Here
    */


    public function piplev5($workbench_id)

    {
        /*
             The supported parameters are:
                email, webhook_url, given_name(First name of person), family_name, ip_address, location, company, company_domain
                linkedin, twitter, facebook
        */
        $rules = [
            'p_email'=>'required|email',
        ];
        $v = Validator::make(Input::all(), $rules, [
            "p_email.required" => "Please enter email.",
        ]);
        if ($v->fails()) {
            return redirect()->back()->withErrors($v->errors());
        }else {
            $first_name = escape(Input::get('first_name'));
            $middle_name = escape(Input::get('middle_name'));
            $last_name = escape(Input::get('last_name'));
            if ($middle_name != '') {
                $names = $first_name . ' ' . $middle_name . ' ' . $last_name;
            }
            else {
                $names = $first_name . ' ' . $last_name;
            }


            $email = Input::get('p_email');
            $phone_number = Input::get('phone_number');
            $phone = $phone_number[0];
            $f_name = Input::get('first_name');
            $l_name = Input::get('last_name');
            $location = Input::get('p_city');
            //$linkedin = Input::get('p_email');
            //$twitter = Input::get('p_email');
            //$facebook = Input::get('p_email');
            $secret_key= env('CLEARBIT_SECRET_API_KEY');
            $endpoint= 'https://person-stream.clearbit.com/v2/combined/find?';
            if(!empty($email))
            {
                $endpoint.= 'email='.$email;
            }
            if(!empty($phone))
            {
                $endpoint.= '&phone='.$phone;
            }
            if(!empty($f_name))
            {
                $endpoint.= '&given_name='.$f_name;
            }
            if(!empty($l_name))
            {
                $endpoint.= '&family_name='.$l_name;
            }
            if(!empty($location))
            {
                $endpoint.= '&location='.$location;
            }
//            dd($endpoint);

            //"https://api.pipl.com/search/?email=pags6273@cox.net&phone=+1%20%28860%29%20987-2151&first_name=John&last_name=Pagliaro&middle_name=A&country=US&state=North%20Granby&city=CT&username=sonnypagliaro&age=46&key=q7qn2sly4b5ak5e0h161ur59&minimum_probability=0.8"
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => $endpoint,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                    "Accept: */*",
//                    "Accept-Encoding: gzip, deflate",
                    "Cache-Control: no-cache",
                    "Connection: keep-alive",
//                    "Host: api.pipl.com",
//                    "Postman-Token: a810431f-7420-4dbd-8f69-87d46dd2531f,1742065f-e3d0-408d-a842-298033c6912e",
//                    "User-Agent: PostmanRuntime/7.18.0",
//                    "cache-control: no-cache"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                echo "cURL Error #:" . $err;
                die;
            } else {
                // Get match score
                $score = $this->calc_score($response);

                Notification::Notify(
                    (Auth::user()->user_type == 1)  ? 1 : Auth::user()->user_type,
                    $this->to_id,
                    "User: ".Auth::user()->name." (Having Role: ".Auth::user()->role->name.") "."searched person record against name: ".$names." successfully using Clearbit API",
                    '/admin-dashboard/workbench/personal',
                    Auth::user()->id,
                    ' bg-inverse-secondary text-info',
                    'mdi mdi-account-search'
                );

                // Save record in a Database
                $result = new Workbench_Result();
                $result->workbench_id = $workbench_id;
                $result->response = json_encode($response);
                $result->score = $score;
                $result->save();
            }
        }
    }
}