<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class w_school extends Model
{
    protected $table = "w_school";
}
